#include<iostream>
#include"PSCommandProvider.h"
using namespace std;


int main()
{
	PSCommandProvider PSCP;
	PSCP.RunProgramm();

	cout << "End";

	return 0;
}